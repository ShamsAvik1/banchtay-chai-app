
export default function Home() {
  return (
    <main className="min-h-screen bg-green-50 text-gray-900 p-6 space-y-6">
      <h1 className="text-3xl font-bold text-green-700">বাঁচতে চাই</h1>
      <p className="text-lg">"আজকের দিনটাই হোক তোমার জীবনের নতুন শুরু"</p>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <div className="p-4 bg-white shadow rounded-2xl">🎥 ভিডিও দেখুন</div>
        <div className="p-4 bg-white shadow rounded-2xl">💊 ড্রাগ সাপোর্ট</div>
        <div className="p-4 bg-white shadow rounded-2xl">🧠 হতাশা সমাধান</div>
        <div className="p-4 bg-white shadow rounded-2xl">🤝 একাকিত্ব দূর করুন</div>
      </div>

      <footer className="text-sm text-center text-gray-600 pt-6 border-t">
        যোগাযোগ: 01827185556 | smavik00@gmail.com<br />
        বিকাশ ডোনেশন: 01827185556
      </footer>
    </main>
  );
}
