
export const metadata = {
  title: "বাঁচতে চাই",
  description: "বাংলা মোটিভেশনাল ও রিহ্যাব সহায়তা অ্যাপ",
};

export default function RootLayout({ children }) {
  return (
    <html lang="bn">
      <body>{children}</body>
    </html>
  );
}
